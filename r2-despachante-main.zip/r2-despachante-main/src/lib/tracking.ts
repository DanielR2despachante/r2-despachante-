// Tracking utilities for conversion events

declare global {
  interface Window {
    fbq?: (action: string, event: string, params?: Record<string, unknown>) => void;
    gtag?: (action: string, target: string, params?: Record<string, unknown>) => void;
  }
}

export const trackWhatsAppClick = (source: string) => {
  // Facebook Pixel tracking
  if (typeof window !== 'undefined' && window.fbq) {
    window.fbq('track', 'Contact', { source });
  }
  
  // Google Ads conversion tracking
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', 'conversion', {
      send_to: 'AW-CONVERSION_ID/CONVERSION_LABEL',
      event_category: 'engagement',
      event_label: `whatsapp_${source}`,
    });
  }
};

export const trackPhoneClick = (source: string) => {
  // Facebook Pixel tracking
  if (typeof window !== 'undefined' && window.fbq) {
    window.fbq('track', 'Contact', { source, type: 'phone' });
  }
  
  // Google Ads conversion tracking
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', 'conversion', {
      send_to: 'AW-CONVERSION_ID/CONVERSION_LABEL',
      event_category: 'engagement',
      event_label: `phone_${source}`,
    });
  }
};

export const trackChecklistComplete = () => {
  // Facebook Pixel tracking
  if (typeof window !== 'undefined' && window.fbq) {
    window.fbq('track', 'Lead', { source: 'checklist_complete' });
  }
  
  // Google Ads conversion tracking
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', 'conversion', {
      send_to: 'AW-CONVERSION_ID/CONVERSION_LABEL',
      event_category: 'lead',
      event_label: 'checklist_complete',
    });
  }
};
