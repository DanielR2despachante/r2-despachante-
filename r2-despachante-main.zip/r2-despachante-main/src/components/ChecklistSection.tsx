import { useState } from "react";
import { Checkbox } from "./ui/checkbox";
import { Button } from "./ui/button";
import { MessageCircle, FileCheck } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { trackWhatsAppClick, trackChecklistComplete } from "@/lib/tracking";

const checklistItems = [
  { id: "rg", label: "RG ou CNH (documento com foto)" },
  { id: "cpf", label: "CPF" },
  { id: "comprovante", label: "Comprovante de Residência atualizado" },
  { id: "crlv", label: "CRLV do veículo" },
  { id: "renavam", label: "Número do Renavam" },
];

export const ChecklistSection = () => {
  const [checkedItems, setCheckedItems] = useState<string[]>([]);

  const handleCheck = (itemId: string) => {
    const newItems = checkedItems.includes(itemId)
      ? checkedItems.filter((id) => id !== itemId)
      : [...checkedItems, itemId];
    
    setCheckedItems(newItems);
    
    // Track when all items are checked
    if (newItems.length === checklistItems.length) {
      trackChecklistComplete();
    }
  };

  const allChecked = checkedItems.length === checklistItems.length;

  const handleWhatsAppClick = () => {
    trackWhatsAppClick('checklist_section');
    window.open(
      "https://wa.me/551150216868?text=Olá! Tenho todos os documentos e quero solicitar atendimento.",
      "_blank"
    );
  };

  return (
    <section className="py-12 sm:py-16 bg-card/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="max-w-2xl mx-auto"
        >
          <div className="text-center mb-8">
            <FileCheck className="h-12 w-12 text-primary mx-auto mb-4" />
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Checklist de Documentos
            </h2>
            <p className="text-lg text-muted-foreground">
              Separe estes documentos antes de solicitar o atendimento
            </p>
          </div>

          <div className="bg-card border border-border rounded-xl p-6 sm:p-8 space-y-4">
            {checklistItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/30 transition-colors"
              >
                <Checkbox
                  id={item.id}
                  checked={checkedItems.includes(item.id)}
                  onCheckedChange={() => handleCheck(item.id)}
                  className="mt-1"
                />
                <label
                  htmlFor={item.id}
                  className="text-foreground cursor-pointer flex-1"
                >
                  {item.label}
                </label>
              </motion.div>
            ))}
          </div>

          <AnimatePresence>
            {allChecked && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="mt-6 text-center"
              >
                <div className="bg-primary/10 border-2 border-primary/30 rounded-xl p-6 mb-4">
                  <p className="text-lg font-semibold text-foreground mb-2">
                    ✅ Perfeito! Você tem tudo que precisa
                  </p>
                  <p className="text-muted-foreground">
                    Agora é só solicitar o atendimento pelo WhatsApp
                  </p>
                </div>
                
                <Button
                  onClick={handleWhatsAppClick}
                  size="lg"
                  variant="hero"
                  className="gap-2 shadow-glow gtm-clique-whatsapp"
                >
                  <MessageCircle className="h-5 w-5" />
                  Solicitar Atendimento Agora
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          {!allChecked && (
            <p className="text-center text-sm text-muted-foreground mt-4">
              Marque todos os itens que você possui
            </p>
          )}
        </motion.div>
      </div>
    </section>
  );
};
