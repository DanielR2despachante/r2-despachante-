import { Shield, CheckCircle, Lock, Star, Award } from "lucide-react";
import { motion } from "framer-motion";

const certifications = [
  {
    icon: Award,
    title: "Despachante Credenciado",
    subtitle: "DETRAN-SP"
  },
  {
    icon: Shield,
    title: "Pagamento Seguro",
    subtitle: "SSL Certificado"
  },
  {
    icon: CheckCircle,
    title: "CNPJ Regularizado",
    subtitle: "Empresa Legal"
  },
  {
    icon: Lock,
    title: "Dados Protegidos",
    subtitle: "LGPD Compliant"
  },
  {
    icon: Star,
    title: "101 Avaliações 5⭐",
    subtitle: "Google Reviews"
  }
];

export const CertificationsSection = () => {
  return (
    <section className="py-8 sm:py-12 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 max-w-5xl mx-auto">
            {certifications.map((cert, index) => {
              const Icon = cert.icon;
              return (
                <motion.div
                  key={cert.title}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="flex flex-col items-center justify-center p-4 bg-card/50 backdrop-blur-sm rounded-lg border border-primary/20 hover:border-primary/40 transition-colors text-center"
                >
                  <Icon className="h-8 w-8 text-primary mb-2" />
                  <p className="text-sm font-semibold text-foreground mb-1">
                    {cert.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {cert.subtitle}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
};
