import { useEffect, useState } from "react";
import { Star, Users, Clock, Award } from "lucide-react";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const AnimatedCounter = ({ end, duration = 2 }: { end: number; duration?: number }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView) return;

    let startTime: number;
    let animationFrame: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = (currentTime - startTime) / (duration * 1000);

      if (progress < 1) {
        setCount(Math.floor(end * progress));
        animationFrame = requestAnimationFrame(animate);
      } else {
        setCount(end);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [end, duration, isInView]);

  return <span ref={ref} className="animate-counter">{count.toLocaleString('pt-BR')}</span>;
};

export const SocialProofSection = () => {
  return (
    <section className="py-12 sm:py-16 bg-card/50">
      <div className="container px-4">
        {/* Rating Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex justify-center mb-8 sm:mb-12 px-4"
        >
          <div className="inline-flex flex-col sm:flex-row items-center gap-2 sm:gap-3 bg-gradient-orange px-4 sm:px-6 py-4 sm:py-3 rounded-2xl sm:rounded-full shadow-glow w-full sm:w-auto max-w-sm sm:max-w-none">
            <div className="flex gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 sm:h-6 sm:w-6 fill-white text-white" />
              ))}
            </div>
            <span className="text-white font-bold text-xl sm:text-2xl">5.0/5.0</span>
            <span className="text-white/90 text-sm sm:text-base text-center">• Baseado em 101 avaliações reais</span>
          </div>
        </motion.div>

        {/* Animated Counters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-center bg-card/50 border border-border rounded-xl p-6"
          >
            <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-primary/20 rounded-full mb-3 sm:mb-4">
              <Users className="h-7 w-7 sm:h-8 sm:w-8 text-primary" />
            </div>
            <div className="text-3xl sm:text-4xl font-bold mb-2">
              <AnimatedCounter end={5000} />+
            </div>
            <p className="text-muted-foreground text-sm sm:text-base">Clientes Satisfeitos</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-center bg-card/50 border border-border rounded-xl p-6"
          >
            <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-primary/20 rounded-full mb-3 sm:mb-4">
              <Award className="h-7 w-7 sm:h-8 sm:w-8 text-primary" />
            </div>
            <div className="text-3xl sm:text-4xl font-bold mb-2">
              <AnimatedCounter end={5} />
            </div>
            <p className="text-muted-foreground text-sm sm:text-base">Anos de Mercado</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-center bg-card/50 border border-border rounded-xl p-6"
          >
            <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 bg-primary/20 rounded-full mb-3 sm:mb-4">
              <Clock className="h-7 w-7 sm:h-8 sm:w-8 text-primary" />
            </div>
            <div className="text-3xl sm:text-4xl font-bold mb-2">
              <AnimatedCounter end={48} />h
            </div>
            <p className="text-muted-foreground text-sm sm:text-base">para Documento Digital</p>
          </motion.div>
        </div>

        {/* Partner Logos */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-16 text-center"
        >
          <p className="text-sm text-muted-foreground mb-6">Credenciados e parceiros oficiais:</p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            <div className="text-2xl font-bold">DETRAN SP</div>
            <div className="text-2xl font-bold">Governo SP</div>
            <div className="text-2xl font-bold">CIRETRAN</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
