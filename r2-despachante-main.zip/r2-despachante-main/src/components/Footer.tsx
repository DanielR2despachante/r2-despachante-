import { MapPin, Phone, Clock, Facebook, Instagram } from "lucide-react";

export const Footer = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <footer className="bg-card border-t border-border">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-orange rounded-lg flex items-center justify-center font-bold text-xl">
                R2
              </div>
              <span className="font-bold text-xl">R2 Despachante</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              A burocracia é nossa. A tranquilidade é sua. Resolva tudo de forma 100% digital.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center hover:bg-primary/30 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5 text-primary" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center hover:bg-primary/30 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5 text-primary" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold mb-4 notranslate" translate="no">Links Rápidos</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <button onClick={() => scrollToSection("hero")} className="hover:text-primary transition-colors notranslate" translate="no">
                  Início
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("how-it-works")} className="hover:text-primary transition-colors notranslate" translate="no">
                  Como Funciona
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("services")} className="hover:text-primary transition-colors notranslate" translate="no">
                  Serviços
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("testimonials")} className="hover:text-primary transition-colors notranslate" translate="no">
                  Depoimentos
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection("location")} className="hover:text-primary transition-colors notranslate" translate="no">
                  Localização
                </button>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-bold mb-4 notranslate" translate="no">Serviços</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="hover:text-primary transition-colors cursor-pointer notranslate" translate="no">Licenciamento 2025</li>
              <li className="hover:text-primary transition-colors cursor-pointer notranslate" translate="no">Transferência de Veículo</li>
              <li className="hover:text-primary transition-colors cursor-pointer notranslate" translate="no">1º Emplacamento</li>
              <li className="hover:text-primary transition-colors cursor-pointer notranslate" translate="no">Liberação de Veículos</li>
              <li className="hover:text-primary transition-colors cursor-pointer notranslate" translate="no">2ª Via de Documentos</li>
              <li className="hover:text-primary transition-colors cursor-pointer notranslate" translate="no">Baixa de Restrições</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold mb-4 notranslate" translate="no">Contato</h3>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <MapPin className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <span>
                  Av. Eng. Armando de Arruda Pereira, 2403<br />
                  Jabaquara, São Paulo - SP<br />
                  CEP: 04309-011
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-primary" />
                <a href="tel:+551150216868" className="hover:text-primary transition-colors gtm-clique-ligacao">
                  (11) 5021-6868
                </a>
              </li>
              <li className="flex items-start gap-2">
              <Clock className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <span>
                Seg-Sex: 9h às 18h<br />
                Sáb-Dom: Fechado
              </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} R2 Despachante. Todos os direitos reservados.</p>
            <div className="flex gap-4">
              <button className="hover:text-primary transition-colors">Política de Privacidade</button>
              <button className="hover:text-primary transition-colors">Termos de Uso</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
