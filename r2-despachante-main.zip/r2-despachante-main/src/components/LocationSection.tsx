import { MapPin, Phone, Clock, Train, Bus } from "lucide-react";
import { motion } from "framer-motion";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";

export const LocationSection = () => {
  const handleWhatsAppClick = () => {
    window.open("https://wa.me/551150216868?text=Olá! Quero agendar uma visita ao escritório.", "_blank");
  };

  const handleDirections = () => {
    window.open("https://www.google.com/maps/search/?api=1&query=Av.+Eng.+Armando+de+Arruda+Pereira,+2403+-+Jabaquara,+São+Paulo", "_blank");
  };

  return (
    <section id="location" className="py-20 bg-background">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center mb-12"
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Venha tomar um{" "}
            <span className="text-primary">café conosco no Jabaquara</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Prefere atendimento presencial? Nossa sede está de portas abertas
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Info Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="bg-card border-border h-full">
              <CardContent className="p-8 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Endereço</h3>
                    <p className="text-muted-foreground">
                      Av. Eng. Armando de Arruda Pereira, 2403<br />
                      Jabaquara, São Paulo - SP<br />
                      CEP: 04309-011
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Contato</h3>
                    <p className="text-muted-foreground">
                      Telefone: (11) 5021-6868<br />
                      WhatsApp: (11) 5021-6868
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">Horário de Atendimento</h3>
                    <p className="text-muted-foreground">
                      Segunda a Sexta: 9h às 18h<br />
                      Sábado e Domingo: Fechado<br />
                      <span className="text-xs text-muted-foreground/70 mt-1 block">
                        * Mensagens no WhatsApp são respondidas no próximo dia útil
                      </span>
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <h3 className="font-bold text-lg mb-4">Como Chegar</h3>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-start gap-3">
                      <Train className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <span className="font-semibold">Metrô:</span> Linha 1-Azul, Estação Jabaquara (1,2 km)
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Bus className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <span className="font-semibold">Ônibus:</span> Linhas 5113-10, 6353-10, 677F-10 e outras
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <Button onClick={handleDirections} variant="hero" size="lg" className="w-full">
                    Ver no Google Maps
                  </Button>
                  <Button onClick={handleWhatsAppClick} variant="outline" size="lg" className="w-full gtm-clique-whatsapp">
                    Agendar Visita
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Map */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="h-[600px] rounded-2xl overflow-hidden border-2 border-border"
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3656.0423!2d-46.6234!3d-23.6234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5a2ba2e7fbbb%3A0x4f4c5b6c3d2e1a0b!2sAv.%20Eng.%20Armando%20de%20Arruda%20Pereira%2C%202403%20-%20Jabaquara%2C%20S%C3%A3o%20Paulo%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Localização R2 Despachante"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};
