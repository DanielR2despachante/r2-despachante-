import { Check, X, Clock, CreditCard, Users, Headphones } from "lucide-react";
import { motion } from "framer-motion";

const comparisonData = [
  {
    feature: "Tempo de Resolução",
    icon: Clock,
    detran: "2-5 dias úteis",
    detranCheck: false,
    r2: "48h digital",
    r2Check: true,
  },
  {
    feature: "Parcelamento",
    icon: CreditCard,
    detran: "Não disponível",
    detranCheck: false,
    r2: "Até 18x",
    r2Check: true,
  },
  {
    feature: "Fila de Espera",
    icon: Users,
    detran: "Sim (horas)",
    detranCheck: false,
    r2: "Não (WhatsApp)",
    r2Check: true,
  },
  {
    feature: "Atendimento",
    icon: Headphones,
    detran: "Horário comercial presencial",
    detranCheck: false,
    r2: "WhatsApp 9h-18h (Seg-Sex)",
    r2Check: true,
  },
];

export const ComparisonTable = () => {
  return (
    <section className="py-12 sm:py-16 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8 sm:mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Por Que Escolher a R2?
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto px-4">
            Compare nosso serviço com o atendimento tradicional do DETRAN
          </p>
        </motion.div>

        {/* Mobile View - Cards */}
        <div className="block lg:hidden max-w-md mx-auto space-y-4">
          {comparisonData.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.feature}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="bg-card border border-border rounded-lg p-4 space-y-3"
              >
                {/* Feature Title */}
                <div className="flex items-center gap-3 pb-2 border-b border-border">
                  <Icon className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="font-bold text-foreground text-base">
                    {item.feature}
                  </span>
                </div>

                {/* DETRAN */}
                <div className="space-y-1">
                  <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                    DETRAN Presencial
                  </div>
                  <div className="flex items-center gap-2">
                    <X className="h-5 w-5 text-destructive flex-shrink-0" />
                    <span className="text-muted-foreground text-sm">
                      {item.detran}
                    </span>
                  </div>
                </div>

                {/* R2 */}
                <div className="space-y-1 bg-primary/5 rounded-lg p-3 border border-primary/20">
                  <div className="text-xs font-medium text-primary uppercase tracking-wide">
                    R2 Despachante ⭐
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-primary flex-shrink-0" />
                    <span className="text-foreground font-semibold text-sm">
                      {item.r2}
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Desktop View - Table */}
        <div className="hidden lg:block max-w-4xl mx-auto overflow-x-auto">
          <div className="min-w-[600px]">
            {/* Header */}
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-muted-foreground">
                  Característica
                </h3>
              </div>
              <div className="text-center bg-muted/30 rounded-lg p-3">
                <h3 className="text-lg font-semibold text-foreground">
                  DETRAN Presencial
                </h3>
              </div>
              <div className="text-center bg-gradient-orange rounded-lg p-3 relative overflow-hidden">
                <div className="absolute inset-0 bg-primary/10" />
                <h3 className="text-lg font-bold text-white relative z-10">
                  R2 Despachante ⭐
                </h3>
              </div>
            </div>

            {/* Rows */}
            <div className="space-y-3">
              {comparisonData.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.feature}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="grid grid-cols-3 gap-4 bg-card border border-border rounded-lg p-4 hover:border-primary/30 transition-colors"
                  >
                    {/* Feature */}
                    <div className="flex items-center gap-3">
                      <Icon className="h-5 w-5 text-primary flex-shrink-0" />
                      <span className="font-medium text-foreground">
                        {item.feature}
                      </span>
                    </div>

                    {/* DETRAN */}
                    <div className="flex items-center justify-center gap-2">
                      {item.detranCheck ? (
                        <Check className="h-5 w-5 text-primary flex-shrink-0" />
                      ) : (
                        <X className="h-5 w-5 text-destructive flex-shrink-0" />
                      )}
                      <span className="text-muted-foreground text-sm">
                        {item.detran}
                      </span>
                    </div>

                    {/* R2 */}
                    <div className="flex items-center justify-center gap-2 bg-primary/5 rounded-lg px-3 py-2">
                      {item.r2Check ? (
                        <Check className="h-5 w-5 text-primary flex-shrink-0" />
                      ) : (
                        <X className="h-5 w-5 text-destructive flex-shrink-0" />
                      )}
                      <span className="text-foreground font-semibold text-sm">
                        {item.r2}
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center mt-8 px-4"
        >
          <p className="text-base sm:text-lg text-muted-foreground mb-4">
            A escolha é clara: <span className="text-primary font-bold">mais rápido, mais fácil, mais conveniente</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
};
