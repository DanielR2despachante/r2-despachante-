import { X } from "lucide-react";
import { motion } from "framer-motion";

const problems = [
  "Sistemas do governo que não funcionam",
  "Risco de multas pesadas e apreensão",
  "Horas perdidas em filas e cartórios",
  "Dúvidas sobre o que realmente precisa pagar",
];

export const ProblemsSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center mb-12"
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            A papelada do seu carro está tirando o seu sono?
          </h2>
          <p className="text-xl text-muted-foreground">
            Você não está sozinho. Esses são os problemas mais comuns que nossos clientes enfrentam:
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {problems.map((problem, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="flex items-start gap-4 p-6 rounded-lg bg-card border border-border hover:border-destructive/50 transition-colors"
            >
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-destructive/20 flex items-center justify-center">
                <X className="h-5 w-5 text-destructive" />
              </div>
              <p className="text-lg text-foreground">{problem}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
