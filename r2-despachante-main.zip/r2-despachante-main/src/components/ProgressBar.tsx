import { useEffect, useState } from "react";
import { motion } from "framer-motion";

export const ProgressBar = () => {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    let ticking = false;
    let cachedScrollHeight = document.documentElement.scrollHeight - window.innerHeight;

    const updateScrollProgress = () => {
      const scrolled = (window.scrollY / cachedScrollHeight) * 100;
      setScrollProgress(Math.min(Math.max(scrolled, 0), 100));
      ticking = false;
    };

    const requestTick = () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(updateScrollProgress);
      }
    };

    const handleResize = () => {
      cachedScrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      updateScrollProgress();
    };

    window.addEventListener("scroll", requestTick, { passive: true });
    window.addEventListener("resize", handleResize, { passive: true });
    
    return () => {
      window.removeEventListener("scroll", requestTick);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-1 bg-primary z-50 origin-left"
      style={{ scaleX: scrollProgress / 100 }}
      initial={{ scaleX: 0 }}
    />
  );
};
