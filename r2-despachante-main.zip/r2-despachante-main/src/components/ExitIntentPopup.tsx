import { useState, useEffect } from "react";
import { X, MessageCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";

export const ExitIntentPopup = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [hasShown, setHasShown] = useState(false);

  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !hasShown) {
        setIsOpen(true);
        setHasShown(true);
      }
    };

    document.addEventListener("mouseleave", handleMouseLeave);
    return () => document.removeEventListener("mouseleave", handleMouseLeave);
  }, [hasShown]);

  const handleWhatsAppClick = () => {
    window.open("https://wa.me/551150216868?text=Olá! Vim pelo site e quero saber mais sobre o licenciamento.", "_blank");
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md bg-card border-primary/20">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-foreground">
            Não deixe a burocracia vencer!
          </DialogTitle>
          <DialogDescription className="text-lg text-muted-foreground">
            Fale com um de nossos especialistas agora, tire sua dúvida na hora e ganhe{" "}
            <span className="text-primary font-bold">10% de desconto</span> para deixar seu veículo 100% em dia.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-3 mt-4">
          <Button onClick={handleWhatsAppClick} variant="hero" size="lg" className="w-full gtm-clique-whatsapp">
            <MessageCircle className="mr-2 h-5 w-5" />
            Falar com Especialista
          </Button>
          <Button onClick={() => setIsOpen(false)} variant="ghost" size="sm">
            Continuar navegando
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
