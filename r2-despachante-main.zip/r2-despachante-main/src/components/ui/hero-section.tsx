import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRightIcon } from "lucide-react";
import { Mockup, MockupFrame } from "@/components/ui/mockup";
import { Glow } from "@/components/ui/glow";
import { cn } from "@/lib/utils";

interface HeroAction {
  text: string;
  href?: string;
  onClick?: () => void;
  icon?: React.ReactNode;
  variant?: "default" | "glow" | "outline" | "hero" | "cta";
  className?: string;
}

interface HeroProps {
  badge?: {
    text: string;
    action: {
      text: string;
      href: string;
    };
  };
  title: string;
  description: string;
  actions: HeroAction[];
  image?: {
    src: string;
    alt: string;
  };
}

export function HeroSection({
  badge,
  title,
  description,
  actions,
  image,
}: HeroProps) {
  return (
    <section
      className={cn(
        "bg-background text-foreground",
        "py-6 sm:py-8 md:py-12 px-4",
        "fade-bottom overflow-hidden pb-0"
      )}
    >
      <div className="mx-auto flex max-w-container flex-col gap-8 pt-4 sm:pt-6 md:pt-8 sm:gap-12">
        <div className="flex flex-col items-center gap-4 text-center sm:gap-6 md:gap-8">
          {/* Badge */}
          {badge && (
            <Badge variant="outline" className="animate-appear gap-2">
              <span className="text-muted-foreground">{badge.text}</span>
              <a href={badge.action.href} className="flex items-center gap-1">
                {badge.action.text}
                <ArrowRightIcon className="h-3 w-3" />
              </a>
            </Badge>
          )}

          {/* Title */}
          <h1 className="relative z-10 inline-block animate-appear bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-4xl font-semibold leading-tight text-transparent drop-shadow-2xl sm:text-5xl sm:leading-tight md:text-6xl md:leading-tight lg:text-7xl lg:leading-tight px-4">
            {title}
          </h1>

          {/* Description */}
          <p className="text-base relative z-10 max-w-[550px] animate-appear font-medium text-muted-foreground opacity-0 delay-100 sm:text-lg md:text-xl px-4">
            {description}
          </p>

          {/* Actions */}
          <div className="relative z-10 w-full flex animate-appear flex-col sm:flex-row justify-center gap-3 sm:gap-4 opacity-0 delay-300 px-4 max-w-full sm:max-w-2xl">
            {actions.map((action, index) => (
              <Button 
                key={index} 
                variant={action.variant || "default"} 
                size="lg"
                onClick={action.onClick}
                asChild={!action.onClick}
                className={cn("w-full sm:w-auto min-h-[56px] text-base sm:text-lg", action.className)}
              >
                {action.onClick ? (
                  <span className="flex items-center justify-center gap-2">
                    {action.icon}
                    <span className="truncate">{action.text}</span>
                  </span>
                ) : (
                  <a href={action.href} className="flex items-center justify-center gap-2">
                    {action.icon}
                    <span className="truncate">{action.text}</span>
                  </a>
                )}
              </Button>
            ))}
          </div>

          {/* Image with Glow (optional) */}
          {image && (
            <div className="relative pt-12 w-full">
              <MockupFrame
                className="animate-appear opacity-0 delay-700"
                size="small"
              >
                <Mockup type="responsive">
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-auto"
                  />
                </Mockup>
              </MockupFrame>
              <Glow
                variant="top"
                className="animate-appear-zoom opacity-0 delay-1000"
              />
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
