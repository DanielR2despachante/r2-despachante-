import { cn } from "@/lib/utils"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Star } from "lucide-react"

export interface TestimonialAuthor {
  name: string
  handle: string
  avatar?: string
  initials: string
}

export interface TestimonialCardProps {
  author: TestimonialAuthor
  text: string
  href?: string
  className?: string
  verified?: boolean
}

export function TestimonialCard({ 
  author,
  text,
  href,
  className,
  verified
}: TestimonialCardProps) {
  const Card = href ? 'a' : 'div'
  
  return (
    <Card
      {...(href ? { href } : {})}
      className={cn(
        "flex flex-col rounded-lg border-t",
        "bg-gradient-to-b from-muted/50 to-muted/10",
        "p-4 text-start sm:p-6",
        "hover:from-muted/60 hover:to-muted/20",
        "max-w-[320px] sm:max-w-[320px]",
        "transition-colors duration-300",
        className
      )}
    >
      <div className="flex items-center gap-3">
        <Avatar className="h-12 w-12">
          {author.avatar && <AvatarImage src={author.avatar} alt={author.name} />}
          <AvatarFallback className="bg-primary/20 text-primary font-semibold">
            {author.initials}
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-col items-start gap-1">
          <div className="flex items-center gap-2">
            <h3 className="text-md font-semibold leading-none">
              {author.name}
            </h3>
            {verified && (
              <Badge variant="secondary" className="text-xs py-0 px-2">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Google
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            {author.handle}
          </p>
          {verified && (
            <div className="flex gap-0.5 mt-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
          )}
        </div>
      </div>
      <p className="sm:text-md mt-4 text-sm text-muted-foreground">
        {text}
      </p>
    </Card>
  )
}
