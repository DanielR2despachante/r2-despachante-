import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

interface FaqItem {
  id: string;
  title: string;
  content: string;
}

interface FaqsSectionProps {
  title?: string;
  description?: string;
  questions: FaqItem[];
  contactText?: string;
  contactLink?: string;
}

export function FaqsSection({ 
  title = "Perguntas Frequentes",
  description = "Tire suas dúvidas sobre nossos serviços",
  questions,
  contactText = "Não encontrou o que procura?",
  contactLink
}: FaqsSectionProps) {
  return (
    <div className="mx-auto w-full max-w-3xl space-y-7 px-4 pt-16">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold md:text-4xl">{title}</h2>
        <p className="text-muted-foreground max-w-2xl">
          {description}
        </p>
      </div>
      <Accordion
        type="single"
        collapsible
        className="bg-card dark:bg-card/50 w-full -space-y-px rounded-lg"
        defaultValue="item-1"
      >
        {questions.map((item) => (
          <AccordionItem
            value={item.id}
            key={item.id}
            className="relative border-x first:rounded-t-lg first:border-t last:rounded-b-lg last:border-b"
          >
            <AccordionTrigger className="px-4 py-4 text-[15px] leading-6 hover:no-underline">
              {item.title}
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground pb-4 px-4">
              {item.content}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
      {contactLink && (
        <p className="text-muted-foreground">
          {contactText}{' '}
          <a href={contactLink} className="text-primary underline hover:underline">
            Fale conosco no WhatsApp
          </a>
        </p>
      )}
    </div>
  );
}
