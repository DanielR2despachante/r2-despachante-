import { useState } from "react";
import { MessageCircle, X, Phone } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./ui/button";
import { trackWhatsAppClick, trackPhoneClick } from "@/lib/tracking";

export const FloatingWhatsApp = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleWhatsAppClick = () => {
    trackWhatsAppClick('floating_button');
    window.open("https://wa.me/551150216868?text=Olá! Vim pelo site e quero fazer o check-up veicular gratuito.", "_blank");
    setIsExpanded(false);
  };

  const handleCallClick = () => {
    trackPhoneClick('floating_button');
    window.location.href = "tel:+551150216868";
    setIsExpanded(false);
  };

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-8 sm:right-8 z-50 flex flex-col items-end gap-3 max-w-[calc(100vw-2rem)]">
      <AnimatePresence>
        {isExpanded && (
          <>
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              transition={{ duration: 0.2 }}
            >
              <Button
                onClick={handleCallClick}
                variant="hero"
                size="lg"
                className="shadow-2xl gap-2 gtm-clique-ligacao"
              >
                <Phone className="h-5 w-5" />
                Ligar Agora
              </Button>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              transition={{ duration: 0.2, delay: 0.05 }}
            >
              <Button
                onClick={handleWhatsAppClick}
                variant="hero"
                size="lg"
                className="shadow-2xl gap-2 flex-col h-auto py-3 gtm-clique-whatsapp-flutuante"
              >
                <div className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                  Falar no WhatsApp
                </div>
                <span className="text-xs opacity-90">Seg-Sex: 9h-18h</span>
              </Button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <motion.div
        className="relative"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        {/* Pulsating glow effect */}
        <motion.div
          className="absolute inset-0 rounded-full bg-primary"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 0, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatType: "loop",
          }}
        />

        <Button
          onClick={() => setIsExpanded(!isExpanded)}
          variant="hero"
          size="icon"
          className="w-16 h-16 rounded-full shadow-2xl relative z-[1] animate-glow-pulse"
          aria-label={isExpanded ? "Fechar menu" : "Abrir menu de contato"}
        >
          <AnimatePresence mode="wait">
            {isExpanded ? (
              <motion.div
                key="close"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <X className="h-6 w-6" />
              </motion.div>
            ) : (
              <motion.div
                key="message"
                initial={{ rotate: 90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: -90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <MessageCircle className="h-6 w-6" />
              </motion.div>
            )}
          </AnimatePresence>
        </Button>
      </motion.div>
    </div>
  );
};
