import { MessageCircle, FileCheck, Smartphone } from "lucide-react";
import { motion } from "framer-motion";
import { FaqsSection } from "./ui/faqs-1";

const steps = [
  {
    number: "01",
    icon: MessageCircle,
    title: "Chame no WhatsApp",
    description: "Envie uma mensagem e um especialista te responde na hora. Compartilhe as informações do veículo.",
  },
  {
    number: "02",
    icon: FileCheck,
    title: "Aprove o Orçamento",
    description: "Receba o valor total com todas as pendências incluídas. Parcele em até 18x.",
  },
  {
    number: "03",
    icon: Smartphone,
    title: "Receba o Documento",
    description: "Em até 48h você tem o documento digital. Pode dirigir tranquilo, 100% regularizado.",
  },
];

const faqs = [
  {
    id: "item-1",
    title: "Quanto tempo demora para resolver tudo?",
    content: "Em média, o documento digital fica pronto em até 48 horas após a aprovação do orçamento. Casos mais complexos podem levar até 5 dias úteis.",
  },
  {
    id: "item-2",
    title: "Posso parcelar os débitos do veículo?",
    content: "Sim! Oferecemos parcelamento em até 18x para IPVA, multas e taxas de licenciamento. Facilitamos ao máximo para você regularizar seu veículo.",
  },
  {
    id: "item-3",
    title: "É seguro enviar meus documentos pelo WhatsApp?",
    content: "Totalmente seguro! Somos um despachante credenciado e seguimos todos os protocolos de segurança. Seus dados são protegidos e usados apenas para os serviços solicitados.",
  },
  {
    id: "item-4",
    title: "Preciso ir até o despachante pessoalmente?",
    content: "Não! Todo o processo é 100% digital pelo WhatsApp. Só recomendamos visita presencial se você preferir atendimento pessoal ou tiver casos muito específicos.",
  },
  {
    id: "item-5",
    title: "O que está incluso no check-up veicular gratuito?",
    content: "Analisamos todas as pendências: IPVA atrasado, multas, débitos de licenciamento, restrições judiciais e administrativas. Você recebe um relatório completo com valores e prazos.",
  },
];

export const HowItWorksSection = () => {
  return (
    <section id="how-it-works" className="py-20 bg-background">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Deixe seu Veículo em Dia em{" "}
            <span className="text-primary">3 Passos Simples</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Processo 100% digital, rápido e sem complicação
          </p>
        </motion.div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-20">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="relative"
            >
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-16 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-primary to-primary/20" />
              )}

              <div className="text-center relative z-10">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-orange rounded-full mb-6 shadow-glow">
                  <step.icon className="h-10 w-10 text-white" />
                </div>
                <div className="text-5xl font-bold text-primary/20 absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 -z-10">
                  {step.number}
                </div>
                <h3 className="text-xl font-bold mb-3 break-words min-h-[3.5rem] flex items-center justify-center">
                  {step.title}
                </h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* FAQ */}
        <FaqsSection
          title="Perguntas Frequentes"
          description="Tire suas dúvidas sobre o processo de licenciamento e regularização veicular"
          questions={faqs}
          contactLink="https://wa.me/551150216868"
        />
      </div>
    </section>
  );
};
