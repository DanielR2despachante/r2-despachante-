import { useState, useEffect } from "react";
import { MessageCircle, Phone, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "./ui/button";

export const FinalCTASection = () => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  const [clientsToday, setClientsToday] = useState(147);

  useEffect(() => {
    // Countdown to end of year 2025 (December 31, 2025)
    const targetDate = new Date("2025-12-31T23:59:59").getTime();

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate - now;

      if (distance < 0) {
        clearInterval(interval);
        return;
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000),
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Simulate clients counter
    const interval = setInterval(() => {
      setClientsToday((prev) => prev + Math.floor(Math.random() * 2));
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const handleWhatsAppClick = () => {
    window.open("https://wa.me/551150216868?text=Olá! Quero garantir minha tranquilidade e regularizar meu veículo agora!", "_blank");
  };

  const handleCallClick = () => {
    window.location.href = "tel:+551150216868";
  };

  return (
    <section className="py-20 bg-gradient-dark relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,107,53,0.15)_0%,transparent_70%)]" />
      
      <div className="container px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Countdown */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 bg-destructive/20 text-destructive px-3 py-2 rounded-full mb-6 text-sm sm:text-base mx-4 sm:mx-0">
              <Clock className="h-4 w-4 sm:h-5 sm:w-5" />
              <span className="font-semibold">2025 está acabando! Regularize antes do Ano Novo</span>
            </div>

            <div className="grid grid-cols-4 gap-2 sm:gap-4 max-w-xl sm:max-w-2xl mx-auto mb-8 px-4 sm:px-0">
              {[
                { label: "Dias", value: timeLeft.days },
                { label: "Horas", value: timeLeft.hours },
                { label: "Minutos", value: timeLeft.minutes },
                { label: "Segundos", value: timeLeft.seconds },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-lg p-2 sm:p-4 border-2 border-primary/30"
                >
                  <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-primary mb-1">
                    {item.value.toString().padStart(2, "0")}
                  </div>
                  <div className="text-xs sm:text-sm text-muted-foreground truncate">{item.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Main CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6 px-4 sm:px-0">
              Não Deixe para a Última Hora de 2025!
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground mb-8 px-4 sm:px-0">
              Regularize seu veículo agora e comece 2026 com tranquilidade
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8 px-4 sm:px-0">
              <Button
                onClick={handleWhatsAppClick}
                variant="hero"
                size="lg"
                className="w-full sm:w-auto text-base sm:text-lg px-4 sm:px-8 py-4 sm:py-6 h-auto gtm-clique-whatsapp"
              >
                <MessageCircle className="mr-2 h-5 w-5 sm:h-6 sm:w-6 flex-shrink-0" />
                <span className="whitespace-normal text-center">Garantir minha Tranquilidade no WhatsApp</span>
              </Button>

              <Button
                onClick={handleCallClick}
                variant="outline"
                size="lg"
                className="w-full sm:w-auto text-base sm:text-lg px-4 sm:px-8 py-4 sm:py-6 h-auto gtm-clique-ligacao"
              >
                <Phone className="mr-2 h-5 w-5 flex-shrink-0" />
                <span className="whitespace-normal text-center">Ligar Agora</span>
              </Button>
            </div>

            {/* Social Proof Counter */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="inline-flex items-center gap-2 text-sm text-muted-foreground bg-card/50 px-6 py-3 rounded-full"
            >
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <span>
                <span className="text-primary font-bold">{clientsToday}</span> motoristas já garantiram a tranquilidade nas últimas 24h
              </span>
            </motion.div>
          </motion.div>

          {/* Trust Badges */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto"
          >
            {[
              { icon: "🔒", text: "Pagamento 100% Seguro" },
              { icon: "⚡", text: "Documento em 48h" },
              { icon: "💳", text: "Parcele em até 18x" },
            ].map((badge, index) => (
              <div
                key={index}
                className="flex items-center justify-center gap-2 bg-card/50 rounded-lg p-4 border border-border"
              >
                <span className="text-2xl">{badge.icon}</span>
                <span className="font-semibold">{badge.text}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};
