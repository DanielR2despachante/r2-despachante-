import { CheckCircle, X, Clock, MessageCircle, Shield, CreditCard } from "lucide-react";
import { motion } from "framer-motion";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";

export const SolutionSection = () => {
  const comparison = [
    {
      problem: "Sistemas complicados e travando",
      solution: "Atendimento humano e rápido via WhatsApp",
    },
    {
      problem: "Espera de semanas pelo documento",
      solution: "Documento digital em até 48h",
    },
    {
      problem: "Perder horas em filas e cartórios",
      solution: "Tudo resolvido sem você sair de casa",
    },
    {
      problem: "Pagar tudo à vista ou não regularizar",
      solution: "Parcelamento de todos os débitos em 18x",
    },
  ];

  const highlights = [
    {
      icon: MessageCircle,
      title: "100% Digital",
      description: "Tudo pelo WhatsApp",
      stat: "5 min",
      statLabel: "tempo médio de resposta",
    },
    {
      icon: Clock,
      title: "Documento Rápido",
      description: "Licença digital em 48h",
      stat: "48h",
      statLabel: "prazo de entrega",
    },
    {
      icon: Shield,
      title: "Despachante Oficial",
      description: "Credenciado no DETRAN",
      stat: "5000+",
      statLabel: "clientes atendidos",
    },
    {
      icon: CreditCard,
      title: "Parcelamento",
      description: "Débitos em até 18x",
      stat: "18x",
      statLabel: "parcelamento",
    },
  ];

  return (
    <section className="py-20 bg-gradient-dark">
      <div className="container px-4">
        {/* Before vs After */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-5xl mx-auto mb-20"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-center mb-12">
            A Diferença é <span className="text-primary">Burocracia Zero</span>
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Problems Column */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-destructive mb-6">Com a Burocracia:</h3>
              {comparison.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3 p-4 rounded-lg bg-card/30 border border-destructive/20"
                >
                  <X className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <p className="text-muted-foreground">{item.problem}</p>
                </motion.div>
              ))}
            </div>

            {/* Solutions Column */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-primary mb-6">Com a R2 Despachante:</h3>
              {comparison.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3 p-4 rounded-lg bg-card border border-primary/20 hover:border-primary/40 transition-colors"
                >
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-foreground font-medium">{item.solution}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Highlight Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {highlights.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-card border-border hover:border-primary/50 transition-all duration-300 h-full hover:shadow-glow">
                <CardContent className="p-6 text-center">
                  <div className="inline-flex items-center justify-center w-14 h-14 bg-primary/20 rounded-full mb-4">
                    <item.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{item.description}</p>
                  <Badge variant="outline" className="border-primary text-primary text-lg font-bold px-3 py-1">
                    {item.stat}
                  </Badge>
                  <p className="text-xs text-muted-foreground mt-2">{item.statLabel}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
