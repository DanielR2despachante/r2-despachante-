import { useState } from "react";
import { Search, FileText, RefreshCw, Car, Truck, Scale, FileCheck, Ban, X } from "lucide-react";
import { motion } from "framer-motion";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";

const services = [
  {
    id: "licenciamento",
    icon: FileText,
    title: "Licenciamento 2025",
    description: "Novembro: Placas final 9 - Renovação obrigatória",
    price: "A partir de R$ 250",
    popular: true,
    details: {
      fullDescription: "Renovação do licenciamento anual do seu veículo de forma 100% digital. Parcelamos todos os débitos em até 18x.",
      includes: ["Documento digital em 48h", "Parcelamento em 18x", "Quitação de IPVA e multas", "Atendimento via WhatsApp"],
      process: "Envie os dados do veículo → Aprovamos o orçamento → Você recebe o documento digital",
    },
    category: "documentacao",
  },
  {
    id: "transferencia",
    icon: RefreshCw,
    title: "Transferência de Veículo",
    description: "Comprou ou vendeu um carro?",
    price: "A partir de R$ 500",
    popular: true,
    details: {
      fullDescription: "Transferência completa de propriedade do veículo com toda segurança jurídica.",
      includes: ["Atualização do documento", "Registro no DETRAN", "Nova placa (se necessário)", "Vistoria incluída"],
      process: "Documentos do comprador e vendedor → Análise → Transferência no DETRAN → Novo documento",
    },
    category: "transferencia",
  },
  {
    id: "primeiro-emplacamento",
    icon: Car,
    title: "1º Emplacamento",
    description: "Carro zero ou importado",
    price: "A partir de R$ 800",
    details: {
      fullDescription: "Primeiro emplacamento de veículos novos ou importados.",
      includes: ["Emissão de placa", "Registro no DETRAN", "Vistoria técnica", "CRLV original"],
      process: "Nota fiscal do veículo → Vistoria → Emplacamento → Entrega do documento",
    },
    category: "emplacamento",
  },
  {
    id: "liberacao-guincho",
    icon: Truck,
    title: "Liberação de Veículos",
    description: "Retirada de pátio/guincho",
    price: "Consulte",
    details: {
      fullDescription: "Liberação rápida de veículos apreendidos ou removidos para pátios e depósitos.",
      includes: ["Análise da apreensão", "Quitação de multas", "Liberação no pátio", "Acompanhamento presencial"],
      process: "Dados da apreensão → Quitação → Liberação → Retirada do veículo",
    },
    category: "liberacao",
  },
  {
    id: "segunda-via",
    icon: FileCheck,
    title: "2ª Via de Documentos",
    description: "CRLV, CNH e mais",
    price: "A partir de R$ 150",
    details: {
      fullDescription: "Emissão de segunda via de documentos perdidos, roubados ou danificados.",
      includes: ["2ª via CRLV", "2ª via CNH", "CRV", "Entrega digital"],
      process: "Solicitação → Emissão no DETRAN → Envio digital ou físico",
    },
    category: "documentacao",
  },
  {
    id: "baixa-restricao",
    icon: Ban,
    title: "Baixa de Restrições",
    description: "Alienação, multas judiciais",
    price: "Consulte",
    details: {
      fullDescription: "Remoção de restrições administrativas, judiciais ou financeiras do veículo.",
      includes: ["Análise da restrição", "Processo junto aos órgãos", "Acompanhamento total", "Regularização completa"],
      process: "Identificação da restrição → Providências legais → Baixa → Documento limpo",
    },
    category: "regularizacao",
  },
  {
    id: "vistoria",
    icon: Scale,
    title: "Vistoria Veicular",
    description: "Transferência, salvados, etc",
    price: "A partir de R$ 150",
    details: {
      fullDescription: "Vistoria técnica obrigatória para diversos procedimentos de trânsito.",
      includes: ["Agendamento no DETRAN", "Acompanhamento", "Laudo técnico", "Registro da vistoria"],
      process: "Agendamento → Vistoria → Laudo → Prosseguimento do processo",
    },
    category: "vistoria",
  },
];

export const ServicesSection = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedService, setSelectedService] = useState<typeof services[0] | null>(null);

  const categories = [
    { id: null, label: "Todos" },
    { id: "documentacao", label: "Documentação" },
    { id: "transferencia", label: "Transferência" },
    { id: "emplacamento", label: "Emplacamento" },
    { id: "liberacao", label: "Liberação" },
    { id: "vistoria", label: "Vistoria" },
    { id: "regularizacao", label: "Regularização" },
  ];

  const filteredServices = services.filter((service) => {
    const matchesSearch =
      service.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || service.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleWhatsAppClick = (serviceName: string) => {
    window.open(
      `https://wa.me/551150216868?text=Olá! Quero saber mais sobre ${serviceName}.`,
      "_blank"
    );
  };

  return (
    <section id="services" className="py-20 bg-gradient-dark">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center mb-12"
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Todos os Serviços para seu{" "}
            <span className="text-primary">Veículo em Dia</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Do licenciamento à transferência, resolvemos tudo de forma rápida e digital
          </p>
        </motion.div>

        {/* Search and Filters */}
        <div className="max-w-4xl mx-auto mb-12 space-y-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Buscar serviço..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 bg-card border-border"
            />
          </div>

        <div className="flex flex-wrap gap-2 justify-center px-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              variant={selectedCategory === category.id ? "hero" : "outline"}
              size="sm"
              className="whitespace-nowrap px-4 min-w-fit"
            >
              {category.label}
            </Button>
          ))}
        </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 max-w-6xl mx-auto px-2 md:px-0">
          {filteredServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-card border-border hover:border-primary/50 transition-all duration-300 h-full cursor-pointer group hover:shadow-glow overflow-hidden">
                <CardHeader>
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center group-hover:bg-primary/30 transition-colors">
                      <service.icon className="h-6 w-6 text-primary" />
                    </div>
                    {service.popular && (
                      <Badge variant="default" className="bg-gradient-orange border-0">
                        Mais Procurado
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl min-h-[3rem]">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-2xl font-bold text-primary">{service.price}</div>
                  <div className="space-y-2">
                    <Button
                      onClick={() => setSelectedService(service)}
                      variant="outline"
                      className="w-full"
                    >
                      Ver Detalhes
                    </Button>
                    <Button
                      onClick={() => handleWhatsAppClick(service.title)}
                      variant="hero"
                      className="w-full gtm-clique-whatsapp"
                    >
                      Solicitar Agora
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Service Detail Modal */}
        <Dialog open={!!selectedService} onOpenChange={() => setSelectedService(null)}>
          <DialogContent className="max-w-2xl bg-card border-primary/20">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-3">
                {selectedService && (
                  <>
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                      <selectedService.icon className="h-6 w-6 text-primary" />
                    </div>
                    {selectedService.title}
                  </>
                )}
              </DialogTitle>
              <DialogDescription className="text-base">
                {selectedService?.details.fullDescription}
              </DialogDescription>
            </DialogHeader>

            {selectedService && (
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-3">O que está incluso:</h4>
                  <ul className="space-y-2">
                    {selectedService.details.includes.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-muted-foreground">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Como funciona:</h4>
                  <p className="text-muted-foreground">{selectedService.details.process}</p>
                </div>

                <div className="bg-primary/10 rounded-lg p-4">
                  <div className="text-3xl font-bold text-primary mb-1">{selectedService.price}</div>
                  <p className="text-sm text-muted-foreground">Parcelamento disponível em até 18x</p>
                </div>

                <Button
                  onClick={() => handleWhatsAppClick(selectedService.title)}
                  variant="hero"
                  size="lg"
                  className="w-full gtm-clique-whatsapp"
                >
                  Solicitar {selectedService.title}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
};
