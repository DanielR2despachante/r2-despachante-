import { motion } from "framer-motion";
import { FileCheck, Smartphone, Clock, Shield } from "lucide-react";

export const GallerySection = () => {
  const images = [
    {
      icon: FileCheck,
      title: "Documentos Digitais",
      description: "CRLV digital em 48h",
    },
    {
      icon: Smartphone,
      title: "Atendimento Digital",
      description: "100% pelo WhatsApp",
    },
    {
      icon: Clock,
      title: "Processo Rápido",
      description: "Sem filas, sem espera",
    },
    {
      icon: Shield,
      title: "Segurança Total",
      description: "Despachante credenciado",
    },
  ];

  return (
    <section className="py-20 bg-gradient-dark">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center mb-12"
        >
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Nossa Forma de Trabalhar
          </h2>
          <p className="text-xl text-muted-foreground">
            Tecnologia e experiência para resolver tudo de forma rápida e eficiente
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {images.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              <div className="aspect-square rounded-2xl bg-card border-2 border-border hover:border-primary/50 transition-all duration-300 overflow-hidden p-8 flex flex-col items-center justify-center text-center">
                <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-primary/30 transition-colors group-hover:scale-110 duration-300">
                  <item.icon className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
