import { HeroSection as HeroSectionUI } from "./ui/hero-section";
import { MessageCircle, Phone, CheckCircle, Shield } from "lucide-react";
import { trackWhatsAppClick, trackPhoneClick } from "@/lib/tracking";

export const HeroSection = () => {
  const handleWhatsAppClick = () => {
    trackWhatsAppClick('hero_section');
    window.open("https://wa.me/551150216868?text=Olá! Quero fazer meu check-up veicular gratuito.", "_blank");
  };
  
  const handleCallClick = () => {
    trackPhoneClick('hero_section');
    window.location.href = "tel:+551150216868";
  };

  return (
    <>
      <HeroSectionUI
        badge={{
          text: "🚀 Licenciamento 2025 já disponível",
          action: {
            text: "Saiba mais",
            href: "#servicos"
          }
        }}
        title="A Burocracia é Nossa. A Tranquilidade é Sua."
        description="Resolva o Licenciamento 2025 e todas as pendências do seu veículo em minutos, direto pelo WhatsApp."
        actions={[
          {
            text: "Pedir Check-up Veicular Grátis",
            onClick: handleWhatsAppClick,
            variant: "hero",
            icon: <MessageCircle className="h-5 w-5" />,
            className: "gtm-clique-whatsapp"
          },
          {
            text: "Ligue Agora: (11) 5021-6868",
            onClick: handleCallClick,
            variant: "outline",
            icon: <Phone className="h-5 w-5" />,
            className: "gtm-clique-ligacao"
          }
        ]}
      />
      
      {/* Social Proof below hero */}
      <div className="container mx-auto px-4 mt-6 sm:mt-8 relative z-20 pb-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-6 max-w-md mx-auto text-sm">
          <div className="flex items-center justify-center gap-2 bg-card/50 border border-border/50 rounded-lg py-3 px-4">
            <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
            <span className="text-muted-foreground">101 avaliações 5⭐ no Google</span>
          </div>
          <div className="flex items-center justify-center gap-2 bg-card/50 border border-border/50 rounded-lg py-3 px-4">
            <Shield className="h-5 w-5 text-primary flex-shrink-0" />
            <span className="text-muted-foreground">Pagamento 100% Seguro</span>
          </div>
        </div>
      </div>
    </>
  );
};
