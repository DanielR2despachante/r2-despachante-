import { useState, useEffect } from "react";
import { Eye } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export const OnlineVisitors = () => {
  const [visitors, setVisitors] = useState(23);

  useEffect(() => {
    const updateVisitors = () => {
      // Random number between 18 and 35
      const newCount = Math.floor(Math.random() * (35 - 18 + 1)) + 18;
      setVisitors(newCount);
    };

    // Update every 5-10 seconds
    const interval = setInterval(updateVisitors, Math.random() * 5000 + 5000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex justify-center py-2">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="inline-flex items-center gap-2 px-4 py-2 bg-card/50 backdrop-blur-sm rounded-full border border-border/50 shadow-sm"
      >
        <Eye className="h-4 w-4 text-primary animate-pulse" />
        <AnimatePresence mode="wait">
          <motion.span
            key={visitors}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.3 }}
            className="text-sm text-muted-foreground"
          >
            <span className="font-semibold text-foreground">{visitors}</span> pessoas{" "}
            <span className="hidden sm:inline">vendo esta página </span>agora
          </motion.span>
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
