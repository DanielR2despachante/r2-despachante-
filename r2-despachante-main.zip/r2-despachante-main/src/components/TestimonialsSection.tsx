import { TestimonialsWithMarquee } from "./ui/testimonials-with-marquee";
import { Star, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const testimonials = [
  {
    author: {
      name: "Carlos Ady Becker",
      handle: "Avaliou no Google",
      initials: "CA",
    },
    text: "Rapidez e muita agilidade a cada processo, sem complicação e excelente atendimento e atenção nas dúvidas que vão surgindo. Recomendo!",
    verified: true,
  },
  {
    author: {
      name: "Marcelo Portilho",
      handle: "Avaliou no Google",
      initials: "MP",
    },
    text: "Daniel fez um atendimento exemplar, transmitiu confiança, rapidez e conhecimento, não tenho nem como agradecer. Muito obrigado Daniel pela sua prestação de serviço.",
    verified: true,
  },
  {
    author: {
      name: "Caroline Assis de Brito",
      handle: "Avaliou no Google",
      initials: "CB",
    },
    text: "Precisei de um serviço com urgência e o Daniel me atendeu super bem e resolveu tudo em 24h. Super recomendo!!!",
    verified: true,
  },
  {
    author: {
      name: "Thomas",
      handle: "Avaliou no Google",
      initials: "TH",
    },
    text: "Exemplo de profissional. Conhece e sabe o que faz. Resolveu meu problema rapidamente e com atenção. Super recomendo.",
    verified: true,
  },
  {
    author: {
      name: "Sueli Belo",
      handle: "Local Guide • Google",
      initials: "SB",
    },
    text: "Extremamente atenciosos. Responde rapidamente pelo whatsapp. Tem o Daniel que é super atencioso.",
    verified: true,
  },
  {
    author: {
      name: "Alexandre",
      handle: "Avaliou no Google",
      initials: "AL",
    },
    text: "Conheci o Daniel através de indicação e foi uma das melhores coisas que aconteceu, é uma pessoa que se preocupa com pessoas, e faz com excelência o trabalho dele.",
    verified: true,
  },
  {
    author: {
      name: "Marcelo Alex",
      handle: "Avaliou no Google",
      initials: "MA",
    },
    text: "Indico o serviço da R2 Despachante, resolveram meu caso com presteza.",
    verified: true,
  },
  {
    author: {
      name: "Michelle Rainer Constantino",
      handle: "Avaliou no Google",
      initials: "MC",
    },
    text: "Atendimento muito bom, extremamente rápido pra resolver e atenciosos, super indico!!!",
    verified: true,
  },
  {
    author: {
      name: "Bruna Xavier",
      handle: "Local Guide • Google",
      initials: "BX",
    },
    text: "Daniel, me ajudou demais, super atencioso e ágil, prestativo além de tudo, super recomendo!!",
    verified: true,
  },
  {
    author: {
      name: "João Ferro",
      handle: "Avaliou no Google",
      initials: "JF",
    },
    text: "Ótima experiência, posso resumir em: honestidade, rapidez, confiança.",
    verified: true,
  },
  {
    author: {
      name: "Flavia Paula",
      handle: "Avaliou no Google",
      initials: "FP",
    },
    text: "Minha experiência foi maravilhosa com a R2 Despachante, me atenderam super rápido, com atenção e cuidado. Amei!",
    verified: true,
  },
  {
    author: {
      name: "Elane Gomboeff",
      handle: "Avaliou no Google",
      initials: "EG",
    },
    text: "Serviço muito bom, atendimento impecável e solucionou meu problema rápido. Recomendo!",
    verified: true,
  },
];

export const TestimonialsSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container px-4">
        {/* Rating Badge do Google */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center justify-center gap-4 mb-8"
        >
          <div className="flex items-center gap-3 bg-gradient-orange px-8 py-4 rounded-full shadow-glow border-2 border-primary/30">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-6 w-6 fill-white text-white" />
              ))}
            </div>
            <div className="border-l border-white/30 pl-4">
              <p className="font-bold text-2xl text-white">5.0/5.0</p>
              <p className="text-sm text-white/90">101 avaliações no Google</p>
            </div>
          </div>
        </motion.div>

        <TestimonialsWithMarquee
          title="Avaliações Reais do Google"
          description="Veja o que nossos clientes estão dizendo sobre a R2 Despachante"
          testimonials={testimonials}
        />

        {/* Botão Ver no Google */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex justify-center mt-12"
        >
          <Button variant="outline" size="lg" asChild>
            <a 
              href="https://g.page/r/CfYourGoogleBusinessId" 
              target="_blank"
              rel="noopener noreferrer"
              className="gap-2"
            >
              <ExternalLink className="h-4 w-4" />
              Ver todas as 101 avaliações no Google
            </a>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};
