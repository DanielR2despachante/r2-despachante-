import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "./ui/button";
import { motion, AnimatePresence } from "framer-motion";

export const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
      setIsMobileMenuOpen(false);
    }
  };

  const handleWhatsAppClick = () => {
    window.open("https://wa.me/551150216868?text=Olá! Vim pelo site e quero falar agora.", "_blank");
  };

  const navItems = [
    { label: "Início", id: "hero", hash: "#inicio" },
    { label: "Como Funciona", id: "how-it-works", hash: "#como-funciona" },
    { label: "Serviços", id: "services", hash: "#servicos" },
    { label: "Depoimentos", id: "testimonials", hash: "#depoimentos" },
    { label: "Localização", id: "location", hash: "#localizacao" },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border">
      <div className="container flex h-20 items-center justify-between max-w-full">
        <a 
          href="#inicio"
          onClick={(e) => {
            e.preventDefault();
            scrollToSection('hero');
          }}
          className="flex items-center md:pl-2 cursor-pointer transition-transform duration-300 hover:scale-105 mx-auto md:mx-0"
        >
          <picture>
            <source srcSet="/logo-r2-despachante.webp" type="image/webp" />
            <img 
              src="/logo-r2-despachante.png" 
              alt="R2 Despachante" 
              className="h-20 w-auto"
              width="133"
              height="80"
              fetchPriority="high"
              loading="eager"
            />
          </picture>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.id}
              href={item.hash}
              onClick={(e) => {
                e.preventDefault();
                scrollToSection(item.id);
              }}
              translate="no"
              className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors cursor-pointer notranslate"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <Button
            onClick={handleWhatsAppClick}
            variant="hero"
            size="lg"
            className="hidden md:flex gtm-clique-whatsapp"
          >
            Fale Agora
          </Button>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden absolute right-4"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Menu"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-border bg-background"
          >
            <nav className="container flex flex-col py-4 gap-4">
              {navItems.map((item) => (
                <a
                  key={item.id}
                  href={item.hash}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection(item.id);
                  }}
                  translate="no"
                  className="text-left py-2 text-base font-medium text-muted-foreground hover:text-primary transition-colors cursor-pointer notranslate"
                >
                  {item.label}
                </a>
              ))}
              <Button
                onClick={handleWhatsAppClick}
                variant="hero"
                size="lg"
                className="w-full mt-2 gtm-clique-whatsapp"
              >
                Fale Agora
              </Button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
