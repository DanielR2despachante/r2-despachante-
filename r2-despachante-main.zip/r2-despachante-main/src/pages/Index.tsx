import { ProgressBar } from "@/components/ProgressBar";
import { BackToTop } from "@/components/BackToTop";
import { ExitIntentPopup } from "@/components/ExitIntentPopup";
import { FloatingWhatsApp } from "@/components/FloatingWhatsApp";
import { OnlineVisitors } from "@/components/OnlineVisitors";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { SocialProofSection } from "@/components/SocialProofSection";
import { CertificationsSection } from "@/components/CertificationsSection";
import { ProblemsSection } from "@/components/ProblemsSection";
import { SolutionSection } from "@/components/SolutionSection";
import { HowItWorksSection } from "@/components/HowItWorksSection";
import { ServicesSection } from "@/components/ServicesSection";
import { ComparisonTable } from "@/components/ComparisonTable";
import { TestimonialsSection } from "@/components/TestimonialsSection";
import { BeforeAfterSection } from "@/components/BeforeAfterSection";
import { GallerySection } from "@/components/GallerySection";
import { LocationSection } from "@/components/LocationSection";
import { ChecklistSection } from "@/components/ChecklistSection";
import { FinalCTASection } from "@/components/FinalCTASection";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <ProgressBar />
      <BackToTop />
      <ExitIntentPopup />
      <FloatingWhatsApp />
      
      <Header />
      <main>
        <OnlineVisitors />
        <HeroSection />
        <SocialProofSection />
        <CertificationsSection />
        <ProblemsSection />
        <SolutionSection />
        <HowItWorksSection />
        <ServicesSection />
        <ComparisonTable />
        <TestimonialsSection />
        <BeforeAfterSection />
        <GallerySection />
        <LocationSection />
        <ChecklistSection />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
